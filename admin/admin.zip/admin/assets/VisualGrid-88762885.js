import{_ as m}from"./VisualGrid.vue_vue_type_script_setup_true_lang-873a4661.js";import"./index-6405d5ac.js";export{m as default};
