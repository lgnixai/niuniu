import{O as e}from"./index-6405d5ac.js";function r(){return e.get("auth/get")}function u(t){return e.put("auth/edit",t,{showSuccessMessage:!0})}export{r as g,u as s};
