import{_ as o}from"./index.vue_vue_type_style_index_0_lang-febcb236.js";import"./index-8676d886.js";/* empty css                    *//* empty css                 */export{o as default};
