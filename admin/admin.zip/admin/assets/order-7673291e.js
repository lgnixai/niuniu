import{O as r}from"./index-8676d886.js";function o(e){return r.get("fengchao/order/list",{params:e})}function a(e){return r.get(`fengchao/order/detail/${e}`)}export{o as a,a as g};
