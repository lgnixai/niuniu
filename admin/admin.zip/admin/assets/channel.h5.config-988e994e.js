const n="是否开启",c="h5域名",i="点击访问",o="h5配置信息",s={isOpen:n,h5DomainName:c,clickVisit:i,H5Info:o};export{o as H5Info,i as clickVisit,s as default,c as h5DomainName,n as isOpen};
