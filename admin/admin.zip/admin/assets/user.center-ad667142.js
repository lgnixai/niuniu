const e="个人中心",a="编辑",s="头像",n="名称",o={personal:e,editPersonal:a,headImg:s,realName:n};export{o as default,a as editPersonal,s as headImg,e as personal,n as realName};
