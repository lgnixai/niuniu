const e="快递品牌",l="请选择",o="服务商",c={expressNoPlaceholder:e,selectPlaceholder:l,deliveryPlaceholder:o};export{c as default,o as deliveryPlaceholder,e as expressNoPlaceholder,l as selectPlaceholder};
