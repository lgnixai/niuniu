import{_ as o}from"./member-gift.vue_vue_type_script_setup_true_lang-9243a9df.js";import"./index-8676d886.js";import"./member-07751448.js";export{o as default};
