const p=""+new URL("apply_empty-3450716b.png",import.meta.url).href;export{p as _};
