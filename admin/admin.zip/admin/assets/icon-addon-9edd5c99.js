const o=""+new URL("icon-addon-6e08a456.png",import.meta.url).href;export{o as _};
