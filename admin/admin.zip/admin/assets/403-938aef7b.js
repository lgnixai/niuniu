const s="Your account permissions are insufficient. Please contact the administrator to add permissions!",t={tips:s};export{t as default,s as tips};
