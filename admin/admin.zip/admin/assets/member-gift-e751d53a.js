import{_ as o}from"./member-gift.vue_vue_type_script_setup_true_lang-a7d259db.js";import"./index-6405d5ac.js";import"./member-6625bfcc.js";export{o as default};
