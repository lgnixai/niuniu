import{_ as o}from"./upload-media.vue_vue_type_script_setup_true_lang-7881078b.js";import"./index-6405d5ac.js";/* empty css                    */export{o as default};
