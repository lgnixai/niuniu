import{_ as o}from"./upload-media.vue_vue_type_script_setup_true_lang-0ff7a395.js";import"./index-8676d886.js";/* empty css                    */export{o as default};
