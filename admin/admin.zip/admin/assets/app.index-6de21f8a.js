const a="应用名称",p="请输入应用名称",e="暂无应用",t={appName:a,appNamePlaceholder:p,emptyAppData:e};export{a as appName,p as appNamePlaceholder,t as default,e as emptyAppData};
