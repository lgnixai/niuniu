const t="插件名称",o="插件标识",a="插件类型",e="应用",n="插件",p={title:t,key:o,type:a,app:e,addon:n};export{n as addon,e as app,p as default,o as key,t as title,a as type};
