const t="协议类型",e="协议标题",n="修改时间",o="设置",a={typeName:t,title:e,updateTime:n,config:o};export{o as config,a as default,e as title,t as typeName,n as updateTime};
