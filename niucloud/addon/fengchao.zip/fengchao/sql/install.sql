
-- ----------------------------
-- Table structure for {{prefix}}fengchao_delivery_company
-- ----------------------------
DROP TABLE IF EXISTS `{{prefix}}fengchao_delivery_company`;
CREATE TABLE `{{prefix}}fengchao_delivery_company`  (
                                                 `company_id` int NOT NULL AUTO_INCREMENT,
                                                 `site_id` int NOT NULL DEFAULT 0 COMMENT '站点id',
                                                 `company_name` varchar(255)  NOT NULL DEFAULT '' COMMENT '物流公司名称',
                                                 `logo` varchar(255)  NOT NULL DEFAULT '' COMMENT '物流公司logo',
                                                 `url` varchar(255)  NOT NULL DEFAULT '' COMMENT '物流公司网站',
                                                 `express_no` varchar(255)  NOT NULL DEFAULT '' COMMENT '物流公司编号(用于物流跟踪)',
                                                 `express_no_electronic_sheet` varchar(255)  NOT NULL DEFAULT '' COMMENT '物流公司编号(用于电子面单)',
                                                 `electronic_sheet_switch` tinyint NOT NULL DEFAULT 0 COMMENT '是否支持电子面单（0：不支持，1：支持）',
                                                 `create_time` int NOT NULL DEFAULT 0,
                                                 `update_time` int NOT NULL DEFAULT 0,
                                                 PRIMARY KEY (`company_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 13 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for {{prefix}}fengchao_order
-- ----------------------------
DROP TABLE IF EXISTS `{{prefix}}fengchao_order`;
CREATE TABLE `{{prefix}}fengchao_order`  (
                                      `id` bigint NOT NULL AUTO_INCREMENT COMMENT '订单唯一ID',
                                      `site_id` int NOT NULL DEFAULT 0 COMMENT '站点id',
                                      `order_code` varchar(255)  NOT NULL COMMENT '商家订单编号',
                                      `kdn_code` varchar(255)  NOT NULL COMMENT '第三方快递鸟编号',
                                      `client_data` longtext  NOT NULL COMMENT '下游提交的信息',
                                      `server_data` longtext  NOT NULL COMMENT '服务端最终确认的信息',
                                      `price_data` longtext  NOT NULL COMMENT '包含采购价和销售价',
                                      `result_price` longtext  NOT NULL COMMENT '服务商最终价格',
                                      `create_time` int NOT NULL DEFAULT 0 COMMENT '创建时间',
                                      `update_time` int NOT NULL COMMENT '更新时间',
                                      `user_price` longtext  NOT NULL COMMENT '最终展示给客户的价格',
                                      PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARSET=utf8mb4 COLLATE utf8mb4_general_ci COMMENT = '订单信息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for {{prefix}}fengchao_order_callback_log
-- ----------------------------
DROP TABLE IF EXISTS `{{prefix}}fengchao_order_callback_log`;
CREATE TABLE `{{prefix}}fengchao_order_callback_log`  (
                                                   `id` bigint NOT NULL AUTO_INCREMENT COMMENT '订单唯一ID',
                                                   `site_id` int NOT NULL DEFAULT 0 COMMENT '站点id',
                                                   `order_code` varchar(30)  NOT NULL COMMENT '商家订单编号',
                                                   `state` varchar(30)  NOT NULL COMMENT '状态码',
                                                   `kdn_code` varchar(30)  NOT NULL COMMENT '第三方快递鸟编号',
                                                   `server_data` longtext  NOT NULL COMMENT '服务端最终确认的信息',
                                                   `create_time` int NOT NULL DEFAULT 0 COMMENT '创建时间',
                                                   PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARSET=utf8mb4 COLLATE utf8mb4_general_ci COMMENT = '站点回调日志表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for {{prefix}}fengchao_order_log
-- ----------------------------
DROP TABLE IF EXISTS `{{prefix}}fengchao_order_log`;
CREATE TABLE `{{prefix}}fengchao_order_log`  (
                                          `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
                                          `site_id` int NOT NULL DEFAULT 0 COMMENT '站点id',
                                          `request_type` varchar(255)  NOT NULL COMMENT '业务类型',
                                          `request_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '业务数据',
                                          `create_time` int NOT NULL DEFAULT 0 COMMENT '创建时间',
                                          `memo` varchar(255)  NOT NULL DEFAULT '' COMMENT '备注信息',
                                          `response_data` longtext  NOT NULL COMMENT '服务端数据',
                                          PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 101 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '站点请求和回调日志' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for {{prefix}}fengchao_site
-- ----------------------------
DROP TABLE IF EXISTS `{{prefix}}fengchao_site`;
CREATE TABLE `{{prefix}}fengchao_site`  (
                                     `site_id` int NOT NULL DEFAULT 0 COMMENT '站点id',
                                     `balance` decimal(10, 2) NOT NULL DEFAULT 0.00 COMMENT '可用余额',
                                     `balance_get` decimal(10, 2) NOT NULL DEFAULT 0.00 COMMENT '累计获取余额',
                                     `delete_time` int NOT NULL DEFAULT 0 COMMENT '删除时间',
                                     `update_time` int NOT NULL DEFAULT 0 COMMENT '修改时间',
                                     PRIMARY KEY (`site_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '站点信息' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for {{prefix}}fengchao_site_auth
-- ----------------------------
DROP TABLE IF EXISTS `{{prefix}}fengchao_site_auth`;
CREATE TABLE `{{prefix}}fengchao_site_auth`  (
                                          `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
                                          `site_id` int NOT NULL DEFAULT 0 COMMENT '站点id',
                                          `api_name` varchar(255)  NOT NULL DEFAULT '' COMMENT 'ApiName',
                                          `api_key` text  NOT NULL COMMENT 'api_key',
                                          `api_secret` text  NOT NULL COMMENT 'api_secret',
                                          `callback_url` text  NOT NULL COMMENT '回调url',
                                          `delete_time` int NOT NULL DEFAULT 0 COMMENT '删除时间',
                                          `create_time` int NOT NULL DEFAULT 0 COMMENT '创建时间',
                                          PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '站点api验证' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for {{prefix}}fengchao_site_balance_log
-- ----------------------------
DROP TABLE IF EXISTS `{{prefix}}fengchao_site_balance_log`;
CREATE TABLE `{{prefix}}fengchao_site_balance_log`  (
                                                 `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
                                                 `member_id` int NOT NULL DEFAULT 0 COMMENT '用户id',
                                                 `site_id` int NOT NULL DEFAULT 0 COMMENT '站点id',
                                                 `account_type` varchar(255)  NOT NULL DEFAULT 'point' COMMENT '账户类型',
                                                 `account_data` decimal(10, 2) NOT NULL DEFAULT 0.00 COMMENT '账户数据',
                                                 `account_sum` decimal(10, 2) NOT NULL DEFAULT 0.00 COMMENT '变动后的账户余额',
                                                 `from_type` varchar(255)  NOT NULL DEFAULT '' COMMENT '来源类型',
                                                 `related_id` varchar(50)  NOT NULL DEFAULT '' COMMENT '关联Id',
                                                 `create_time` int NOT NULL DEFAULT 0 COMMENT '创建时间',
                                                 `memo` varchar(255)  NOT NULL DEFAULT '' COMMENT '备注信息',
                                                 PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 19 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '会员账单表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Table structure for {{prefix}}fengchao_site_price_template
-- ----------------------------
DROP TABLE IF EXISTS `{{prefix}}fengchao_site_price_template`;
CREATE TABLE `{{prefix}}fengchao_site_price_template`  (
                                                    `template_id` int NOT NULL AUTO_INCREMENT,
                                                    `site_id` int NOT NULL DEFAULT 0 COMMENT '站点id',
                                                    `template_name` varchar(50)  NOT NULL DEFAULT '' COMMENT '模板名称',
                                                    `fee_type` varchar(20)  NOT NULL COMMENT '运费计算方式1.重量2百分比',
                                                    `create_time` int NOT NULL DEFAULT 0 COMMENT '创建时间',
                                                    `update_time` int NOT NULL DEFAULT 0 COMMENT '修改时间',
                                                    PRIMARY KEY (`template_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '运费模板' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for {{prefix}}fengchao_site_price_template_item
-- ----------------------------
DROP TABLE IF EXISTS `{{prefix}}fengchao_site_price_template_item`;
CREATE TABLE `{{prefix}}fengchao_site_price_template_item`  (
                                                         `item_id` int NOT NULL AUTO_INCREMENT,
                                                         `site_id` int NOT NULL DEFAULT 0 COMMENT '站点id',
                                                         `template_id` int NOT NULL DEFAULT 0 COMMENT '模板id',
                                                         `company_id` int NOT NULL DEFAULT 0 COMMENT '物流公司id',
                                                         `snum` int NOT NULL DEFAULT 0 COMMENT '起步计算标准',
                                                         `sprice` decimal(10, 2) NOT NULL DEFAULT 0.00 COMMENT '起步计算价格',
                                                         `xnum` int NOT NULL DEFAULT 0 COMMENT '续步计算标准',
                                                         `xprice` decimal(10, 2) NOT NULL DEFAULT 0.00 COMMENT '续步计算价格',
                                                         `spercent` decimal(10, 2) NOT NULL DEFAULT 0.00 COMMENT '首重按比例加价',
                                                         `xpercent` decimal(10, 2) NOT NULL DEFAULT 0.00 COMMENT '续重按比例加价',
                                                         PRIMARY KEY (`item_id`) USING BTREE,
                                                         INDEX `express_template_item_city_id`(`company_id` ASC) USING BTREE,
                                                         INDEX `express_template_item_template_id`(`template_id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 89 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '运费模板细节' ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;
