
DROP TABLE IF EXISTS `{{prefix}}fengchao_delivery_company`;
DROP TABLE IF EXISTS `{{prefix}}fengchao_order`;
DROP TABLE IF EXISTS `{{prefix}}fengchao_order_callback_log`;
DROP TABLE IF EXISTS `{{prefix}}fengchao_order_log`;
DROP TABLE IF EXISTS `{{prefix}}fengchao_site`;
DROP TABLE IF EXISTS `{{prefix}}fengchao_site_auth`;
DROP TABLE IF EXISTS `{{prefix}}fengchao_site_balance_log`;
DROP TABLE IF EXISTS `{{prefix}}fengchao_site_price_template`;
DROP TABLE IF EXISTS `{{prefix}}fengchao_site_price_template_item`;
 