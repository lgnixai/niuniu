<?php
// +----------------------------------------------------------------------
// | Niucloud-admin 企业快速开发的多应用管理平台
// +----------------------------------------------------------------------
// | 官方网址：https://www.niucloud.com
// +----------------------------------------------------------------------
// | niucloud团队 版权所有 开源版本可自由商用
// +----------------------------------------------------------------------
// | Author: Niucloud Team
// +----------------------------------------------------------------------

namespace addon\fengchao\app\api\controller\express;

use addon\fengchao\app\service\api\common\Utils;
use addon\fengchao\app\service\api\express\ExpressService;
use addon\fengchao\app\service\api\marketing\pointexchange\OrderCreateService;
use core\base\BaseApiController;
use think\Response;


class Order extends BaseApiController
{

    /**
     * 订单创建
     * @return Response
     */
    public function create()
    {
         $site_id= $this->request->siteId();
         $data = $this->request->params([
            [ "api_key", "" ],
            [ "RequestType", "" ],
            [ "RequestData", "" ],
            [ "DataType", 2 ],
            [ "DataSign", "" ]
        ]);
         $params=[];
         $params['RequestType'] = $data['RequestType'];
         $params['RequestData'] = urldecode($data['RequestData']);
         $params['DataType'] = $data['DataType'];
         return   (new ExpressService())->KdniaoDev($params);

    }

    public function test()
    {
        $temp=[];
        $temp["Weight"]=3;
        $temp["Sender"]=[
            "ProvinceName"=>"广东省",
            "CityName"=>"深圳市",
            "ExpAreaName"=>"福田区"
        ];

        $temp["Receiver"]=[
            "ProvinceName"=>"上海市",
            "CityName"=>"上海市",
            "ExpAreaName"=>"嘉定区"
        ];
        $temp_data=[];

        $temp_data["RequestType"]="1815";

        $a= json_encode($temp, JSON_UNESCAPED_UNICODE);

        $escapedJsonString = addslashes($a);
        $jsonInput = [

            'Weight' => 3,
            'Receiver' => [
                'ProvinceName' => '福建省',
                'CityName' => '泉州市',
                'ExpAreaName' => '丰泽区',
            ],
            'Sender' => [
                'ProvinceName' => '广东省',
                'CityName' => '深圳市',
                'ExpAreaName' => '福田区',
            ]

        ];

        // 调用函数生成 requestData
      //  $requestData = convertToRequestData($jsonInput);
        $a= json_encode($jsonInput, JSON_UNESCAPED_UNICODE);

        //$escapedJsonString = addslashes($a);
        $temp_data["RequestData"]=$a;



        $res= (new ExpressService())->Kdniao($temp_data);

        var_dump($res);
    }

    public function get()
    {
        $data["adf"]=1;
        return success('SUCCESS',$data);
    }


}
function convertToRequestData($inputData) {
    // 如果输入是 JSON 字符串，则将其解码为数组
    if (is_string($inputData)) {
        $inputData = json_decode($inputData, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new InvalidArgumentException("Invalid JSON input");
        }
    }

    // 检查是否是数组
    if (!is_array($inputData)) {
        throw new InvalidArgumentException("Input data must be an array or a valid JSON string");
    }

    // 递归格式化数组
    return formatArrayToRequestString($inputData);
}

function formatArrayToRequestString($data, $indent = 0) {
    $output = "{\n";
    $indentation = str_repeat("    ", $indent + 1);  // 每一层增加缩进

    foreach ($data as $key => $value) {
        $formattedKey = "'$key'"; // 使用单引号包裹键

        if (is_array($value)) {
            // 如果值是数组，递归调用函数并增加缩进
            $formattedValue = formatArrayToRequestString($value, $indent + 1);
        } elseif (is_string($value)) {
            // 如果值是字符串，使用单引号包裹
            $formattedValue = "'$value'";
        } else {
            // 其他类型的值直接输出
            $formattedValue = $value;
        }

        $output .= "$indentation$formattedKey: $formattedValue,\n";
    }

    // 去除最后一个多余的逗号
    $output = rtrim($output, ",\n") . "\n";
    $output .= str_repeat("    ", $indent) . "}";

    return $output;
}