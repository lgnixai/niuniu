<?php
// +----------------------------------------------------------------------
// | Niucloud-admin 企业快速开发的多应用管理平台
// +----------------------------------------------------------------------
// | 官方网址：https://www.niucloud.com
// +----------------------------------------------------------------------
// | niucloud团队 版权所有 开源版本可自由商用
// +----------------------------------------------------------------------
// | Author: Niucloud Team
// +----------------------------------------------------------------------

namespace addon\fengchao\app\api\controller\express;

use addon\fengchao\app\service\api\express\ExpressService;
use addon\fengchao\app\service\api\marketing\pointexchange\OrderCreateService;
use core\base\BaseApiController;
use think\Response;
//用户ID，快递鸟提供，注意保管，不要泄漏
defined('EBusinessID') or define('EBusinessID', '01151c7044b1bee82672f1b65cfb1622');//即用户ID，登录快递鸟官网会员中心获取 https://www.kdniao.com/UserCenter/v4/UserHome.aspx
//API key，快递鸟提供，注意保管，不要泄漏
defined('ApiKey') or define('ApiKey', '201bbe9a8b833cfbfb215c19ac721e6db5ff87d39c9b319b4182555fb41800cd');//即API key，登录快递鸟官网会员中心获取 https://www.kdniao.com/UserCenter/v4/UserHome.aspx
//请求url，正式地址
defined('ReqURL') or define('ReqURL', 'http://localhost:8000/api/v1/order');



class SandBoxMe extends BaseApiController
{

    /**
     *  post提交数据
     * @param  string $url 请求Url
     * @param  array $datas 提交的数据
     * @return url响应返回的html
     */
    public function sendPost($url, $datas) {
        $postdata = http_build_query($datas);
        $options = array(
            'http' => array(
                'method' => 'POST',
                'header' => 'Content-type:application/x-www-form-urlencoded',
                'content' => $postdata,
                'timeout' => 15 * 60 // 超时时间（单位:s）
            )
        );
        $context = stream_context_create($options);
        $result = file_get_contents($url, false, $context);


        return $result;
    }

    /**
     * 电商Sign签名生成
     * @param data 内容
     * @param ApiKey ApiKey
     * @return DataSign签名
     */
   public function encrypt($data, $ApiKey) {
        return urlencode(base64_encode(md5($data.$ApiKey)));
    }

    //订单下单
    public function sendOrder(){
        // 组装应用级参数
        $requestData= "{".
            "'OrderCode': '0126570181994',".
            "'ShipperCode': 'SF',".
            "'PayType': 1,".
            "'ExpType': 1,".
            "'Sender': {".
            "'Company': 'LV',".
            "'Name': 'Taylor',".
            "'Mobile': '15018442396',".
            "'ProvinceName': '河北省',".
            "'CityName': '石家庄市',".
            "'ExpAreaName': '新化区',".
            "'Address': '河北省石家庄市新化区幸福里小区 3栋 a001'".
            "},".
            "'Receiver': {".
            "'Company': 'GCCUI',".
            "'Name': 'Yann',".
            "'Mobile': '15018442396',".
            "'ProvinceName': '河南省',".
            "'CityName': '洛阳市',".
            "'ExpAreaName': '涧西区',".
            "'Address': '河南省洛阳市涧西区兴隆花园 201栋三单元 502'".
            "},".
            "'Commodity': [".
            "{".
            "'GoodsName': '鞋子',".
            "'Goodsquantity': 1,".
            "'GoodsWeight': 1.0".
            "}".
            "],".
            "'Weight': 1.0,".
            "'Quantity': 1,".
            "'Volume': 0.0,".
            "'Remark': '小心轻放'".
            "}";
        // 组装系统级参数
        $datas = array(
            'EBusinessID' => EBusinessID,
            'RequestType' => '1801',
            'RequestData' => urlencode($requestData) ,
            'DataType' => '2',
        );
        $datas['DataSign'] = $this->encrypt($requestData, ApiKey);
        //以form表单形式提交post请求，post请求体中包含了应用级参数和系统级参数
        $result=$this->sendPost(ReqURL, $datas);


        //根据公司业务处理返回的信息......


        return  ($result);
    }

    //超区检验接口
  //"{\n  \"Order\" : {\n    \"OrderCode\" : \"012657018199\",\n    \"KDNOrderCode\" : \"KDNSIT2411151410000003\"\n  },\n  \"EBusinessID\" : \"350238\",\n  \"UniquerRequestNumber\" : \"4d614461-c7ba-47ca-ab8c-d029228abfa7\",\n  \"ResultCode\" : \"100\",\n  \"Reason\" : \"快递鸟已接单\",\n  \"Success\" : true\n}\n"
    public function areaCheck(){

        // 组装应用级参数
        $requestData = "{".
            "'TransportType': 1,".
            "'ShipperType': 3,".
            "'Receiver': {".
            "'ProvinceName': '福建省',".
            "'CityName': '泉州市',".
            "'ExpAreaName': '丰泽区',".
            "'Address': '北峰工业区丰盈北路嘉禾酒店楼下李宁店'".
            "},".
            "'Sender': {".
            "'ProvinceName': '广东省',".
            "'CityName': '深圳市',".
            "'ExpAreaName': '福田区',".
            "'Address': '福报街道金花路华宝大厦A栋601'".
            "}".
            "}";
        // 组装系统级参数
        $datas = array(
            'EBusinessID' => EBusinessID,
            'RequestType' => '1814',
            'RequestData' => urlencode($requestData) ,
            'DataType' => '2',
        );
        $datas['DataSign'] = $this->encrypt($requestData, ApiKey);
        //以form表单形式提交post请求，post请求体中包含了应用级参数和系统级参数
        $result=$this->sendPost(ReqURL, $datas);

       echo $result;
       exit;
        //根据公司业务处理返回的信息......
        return $this->getJson($result);

        //return $result;
    }
   //价格预估
    public function pricePre(){
        // 组装应用级参数


        $jsonInput = [
            'TransportType' => 1,
            'ShipperType' => 3,
            'Weight' => 3,
            'Receiver' => [
                'ProvinceName' => '福建省',
                'CityName' => '泉州市',
                'ExpAreaName' => '丰泽区',
            ],
            'Sender' => [
                'ProvinceName' => '广东省',
                'CityName' => '深圳市',
                'ExpAreaName' => '福田区',
            ],
            'InsureAmount' => 1000.00,
        ];

        // 调用函数生成 requestData
        $requestData = convertToRequestData($jsonInput);

        // 组装系统级参数
        $datas = array(
            'EBusinessID' => EBusinessID,
            'RequestType' => '1815',
            'RequestData' => urlencode($requestData) ,
            'DataType' => '2',
        );
        $datas['DataSign'] = $this->encrypt($requestData, ApiKey);
        //以form表单形式提交post请求，post请求体中包含了应用级参数和系统级参数
        $result=$this->sendPost(ReqURL, $datas);
        echo $result;
        exit;
        return $result;

        //return Response::create((json_decode($result)), 'json', 200);



    }

    public function getJson($rawData){

        $cleanData = str_replace(["\n", " "], "", $rawData);
        $cleanData = str_replace(["\n", " "], "", $cleanData);

// 解码 JSON 字符串
        $jsonData = json_decode($cleanData, true);


        return $jsonData;
//        exit;
//        if (json_last_error() === JSON_ERROR_NONE) {
//
//
//            // 输出 JSON 数据
//            return json_encode($jsonData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
//        } else {
//            return "JSON 解码错误: " . json_last_error_msg();
//        }
    }

    public function setData()
    {
        $data = [
            'TransportType' => 1,
            'ShipperType' => 3,
            'Weight' => 3,
            'Receiver' => [
                'ProvinceName' => '福建省',
                'CityName' => '泉州市',
                'ExpAreaName' => '丰泽区',
            ],
            'Sender' => [
                'ProvinceName' => '广东省',
                'CityName' => '深圳市',
                'ExpAreaName' => '福田区',
            ],
            'InsureAmount' => 1000.00,
        ];

// 手动拼接字符串
        $requestData = "{\n" .
            "    'TransportType': " . $data['TransportType'] . ",\n" .
            "    'ShipperType': " . $data['ShipperType'] . ",\n" .
            "    'Weight': " . $data['Weight'] . ",\n" .
            "    'Receiver': {\n" .
            "        'ProvinceName': '" . $data['Receiver']['ProvinceName'] . "',\n" .
            "        'CityName': '" . $data['Receiver']['CityName'] . "',\n" .
            "        'ExpAreaName': '" . $data['Receiver']['ExpAreaName'] . "'\n" .
            "    },\n" .
            "    'Sender': {\n" .
            "        'ProvinceName': '" . $data['Sender']['ProvinceName'] . "',\n" .
            "        'CityName': '" . $data['Sender']['CityName'] . "',\n" .
            "        'ExpAreaName': '" . $data['Sender']['ExpAreaName'] . "'\n" .
            "    },\n" .
            "    'InsureAmount': " . $data['InsureAmount'] . "\n" .
            "}";

        echo $requestData;

// 输出结果

    }
}
function convertToRequestData($inputData) {
    // 如果输入是 JSON 字符串，则将其解码为数组
    if (is_string($inputData)) {
        $inputData = json_decode($inputData, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new InvalidArgumentException("Invalid JSON input");
        }
    }

    // 检查是否是数组
    if (!is_array($inputData)) {
        throw new InvalidArgumentException("Input data must be an array or a valid JSON string");
    }

    // 递归格式化数组
    return formatArrayToRequestString($inputData);
}

function formatArrayToRequestString($data, $indent = 0) {
    $output = "{\n";
    $indentation = str_repeat("    ", $indent + 1);  // 每一层增加缩进

    foreach ($data as $key => $value) {
        $formattedKey = "'$key'"; // 使用单引号包裹键

        if (is_array($value)) {
            // 如果值是数组，递归调用函数并增加缩进
            $formattedValue = formatArrayToRequestString($value, $indent + 1);
        } elseif (is_string($value)) {
            // 如果值是字符串，使用单引号包裹
            $formattedValue = "'$value'";
        } else {
            // 其他类型的值直接输出
            $formattedValue = $value;
        }

        $output .= "$indentation$formattedKey: $formattedValue,\n";
    }

    // 去除最后一个多余的逗号
    $output = rtrim($output, ",\n") . "\n";
    $output .= str_repeat("    ", $indent) . "}";

    return $output;
}