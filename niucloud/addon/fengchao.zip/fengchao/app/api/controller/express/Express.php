<?php
// +----------------------------------------------------------------------
// | Niucloud-admin 企业快速开发的多应用管理平台
// +----------------------------------------------------------------------
// | 官方网址：https://www.niucloud.com
// +----------------------------------------------------------------------
// | niucloud团队 版权所有 开源版本可自由商用
// +----------------------------------------------------------------------
// | Author: Niucloud Team
// +----------------------------------------------------------------------

namespace addon\fengchao\app\api\controller\express;

use addon\fengchao\app\service\api\express\ExpressService;
use addon\fengchao\app\service\api\marketing\pointexchange\OrderCreateService;
use core\base\BaseApiController;
use think\facade\Log;
use think\Response;


class Express extends BaseApiController
{

    /**
     * 订单创建
     * @return Response
     */
    public function notify()
    {

         $data = $this->request->params([
             ["RequestData",''],
             ["DataSign",''],
             ["RequestType",''],
         ]);

        Log::write('订单AfterOrderCreate' . json_encode($data,JSON_UNESCAPED_UNICODE));


        $data=json_encode($data,JSON_UNESCAPED_UNICODE);
        $res=[];
        $res["EBusinessID"] = "350231";
        $res["Success"] = true;
        $res["Reason"] = "成功";
        $res["UpdateTime"] = date('Y-m-d H:i:s');


        event('ListenNotifyAfter',json_decode($data,true));

        //var_dump($res);
        return  json_encode($res);
    }


}
