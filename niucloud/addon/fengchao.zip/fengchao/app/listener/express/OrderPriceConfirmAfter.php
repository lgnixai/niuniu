<?php
declare ( strict_types = 1 );

namespace addon\fengchao\app\listener\express;

use addon\fengchao\app\service\api\order\OrderCallBackLogService;

use addon\fengchao\app\service\api\order\OrderService;
use think\facade\Log;

class OrderPriceConfirmAfter
{

    public function handle($data)
    {
        Log::write('价格确认' . json_encode($data));

        $order["order_code"]=$data["OrderCode"];
        $order["result_price"]=$data;


        $order_info=(new OrderService())->getInfo($order["order_code"]);

        $info=$order_info["price_data"];

        $weight=max($data["Weight"],$data["VolumeWeight"]);

        // 续重*续重卖价
        $continuous_amount=$info["sellContinuousWeightPrice"]*ceil($weight-$info["firstWeight"]);


        $firstWeightAmount=max($info["sellFirstWeightAmount"],$data["FirstWeightAmount"]);
        $ContinuousWeightAmount=max($continuous_amount,$data["ContinuousWeightAmount"]);
        $cost=sprintf("%.2f",$firstWeightAmount+$continuous_amount);

        $TotalFee=sprintf("%.2f",$cost+$data["InsureAmount"]+$data["PackageFee"]+$data["OverFee"]+$data["OtherFee"]);


        // 重量取较大值
        $temp=[
            "Weight"=>$weight,
            "firstWeight"=>$info["firstWeight"],
            "continuousWeight"=>ceil($weight-$info["firstWeight"]),
            "firstWeightAmount"=>$firstWeightAmount,
            "ContinuousWeightAmount"=>$ContinuousWeightAmount,
            "Cost"=>sprintf("%.2f",$firstWeightAmount+$continuous_amount),

            "InsureAmount"=>$data["InsureAmount"],
            "PackageFee"=>$data["PackageFee"],
            "OverFee"=>$data["OverFee"],
            "OtherFee"=>$data["OtherFee"],
            "OtherFeeDetail"=>$data["OtherFeeDetail"],
            "TotalFee"=>max($TotalFee,$data["TotalFee"]),
            "Volume"=>$data["Volume"],
            "VolumeWeight"=>$data["VolumeWeight"]
        ];

        $order["user_price"]=$temp;


        $id=(new OrderService())->update($order);



    }
}
