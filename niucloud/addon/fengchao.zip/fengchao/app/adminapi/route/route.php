<?php

use app\adminapi\middleware\AdminCheckRole;
use app\adminapi\middleware\AdminCheckToken;
use app\adminapi\middleware\AdminLog;
use think\facade\Route;

/**
 * 商城系统
 */
//暂时为测试用
Route::group('api', function () {
    Route::get('company', 'addon\fengchao\app\adminapi\controller\api\Company@all');
    Route::get('createApiKey', 'addon\fengchao\app\adminapi\controller\api\token@createApiKey');
    Route::get('getApiKey', 'addon\fengchao\app\adminapi\controller\api\token@getApiKey');

});


Route::group('v1', function () {

    // 退款方式
    Route::post('order', 'addon\fengchao\app\api\controller\express\order@create');
    Route::get('order', 'addon\fengchao\app\api\controller\express\order@get');

})->middleware(\addon\fengchao\app\api\middleware\ApiCheckSign::class)
    ->middleware(\app\api\middleware\ApiLog::class);

/**沙盒环境**/
Route::group('sandbox', function () {

    // 退款方式
    Route::post('order', 'addon\fengchao\app\adminapi\controller\sandbox\SandBox@create');

})->middleware(\addon\fengchao\app\api\middleware\ApiCheckSign::class)
    ->middleware(\app\api\middleware\ApiLog::class);


Route::group('fengchao', function () {

    Route::get('delivery/company/all', 'addon\fengchao\app\adminapi\controller\delivery\Company@all');

    //会员余额流水
    Route::get('site/balance', 'addon\fengchao\app\adminapi\controller\site\Balance@siteBalanceList');
    Route::post('site/balance/adjust', 'addon\fengchao\app\adminapi\controller\site\Balance@adjustBalance');
    Route::get('site/price/template/site/:site_id', 'addon\fengchao\app\adminapi\controller\site\PriceTemplate@site_info');
    Route::put('site/price/template/:template_id', 'addon\fengchao\app\adminapi\controller\site\PriceTemplate@edit');



    //网站端相关
    Route::get('site/api/list', 'addon\fengchao\app\adminapi\controller\api\Api@lists');
    Route::get('site/api/createNewApi', 'addon\fengchao\app\adminapi\controller\api\Api@createNewApi');
    Route::get('site/api/getApi/:id', 'addon\fengchao\app\adminapi\controller\api\Api@info');
    Route::post('site/api/add', 'addon\fengchao\app\adminapi\controller\api\Api@add');
    Route::delete('site/api/:id', 'addon\fengchao\app\adminapi\controller\api\Api@del');
    Route::get('site/allBalance', 'addon\fengchao\app\adminapi\controller\site\Balance@siteBalanceList');
    Route::get('site/siteBalance', 'addon\fengchao\app\adminapi\controller\site\Balance@BalanceBySiteList');
    Route::post('site/api/sandbox', 'addon\fengchao\app\adminapi\controller\sandbox\SandBox@kuaidiniao');


    //订单列表
    Route::get('order/list', 'addon\fengchao\app\adminapi\controller\order\Order@lists');

    //订单详情
    Route::get('order/detail/:id', 'addon\fengchao\app\adminapi\controller\order\Order@detail');


    Route::get('sandbox/fake/list', 'addon\fengchao\app\adminapi\controller\sandbox\FakeData@list');
    Route::get('sandbox/fake/:id', 'addon\fengchao\app\adminapi\controller\sandbox\FakeData@fake');



    /************************************************** 配送相关接口 *****************************************************/
    //物流公司 分页列表
    Route::get('delivery/company', 'addon\fengchao\app\adminapi\controller\delivery\Company@pages');
    Route::post('delivery/company/init', 'addon\fengchao\app\adminapi\controller\delivery\Company@init');

    //物流公司 列表
    Route::get('delivery/company/list', 'addon\fengchao\app\adminapi\controller\delivery\Company@lists');

    //物流公司 详情
    Route::get('delivery/company/:id', 'addon\fengchao\app\adminapi\controller\delivery\Company@info');

    //物流公司 添加
    Route::post('delivery/company', 'addon\fengchao\app\adminapi\controller\delivery\Company@add');

    //物流公司 编辑
    Route::put('delivery/company/:id', 'addon\fengchao\app\adminapi\controller\delivery\Company@edit');

    //物流公司 删除
    Route::delete('delivery/company/:id', 'addon\fengchao\app\adminapi\controller\delivery\Company@del');

    //物流查询接口 设置
    Route::post('delivery/search', 'addon\fengchao\app\adminapi\controller\delivery\DeliverySearch@setConfig');

    //物流跟踪接口 查询
    Route::get('delivery/search', 'addon\fengchao\app\adminapi\controller\delivery\DeliverySearch@getConfig');


    //运费模版 分页列表
    Route::get('shipping/template', 'addon\fengchao\app\adminapi\controller\delivery\ShippingTemplate@pages');

    //运费模版 列表
    Route::get('shipping/template/list', 'addon\fengchao\app\adminapi\controller\delivery\ShippingTemplate@lists');

    //运费模版 详情
    Route::get('shipping/template/:template_id', 'addon\fengchao\app\adminapi\controller\delivery\ShippingTemplate@info');

    //站点对应运费模版 详情
    Route::get('shipping/template/site/:site_id', 'addon\fengchao\app\adminapi\controller\delivery\ShippingTemplate@site_info');

    //运费模版 添加
    Route::post('shipping/template', 'addon\fengchao\app\adminapi\controller\delivery\ShippingTemplate@add');

    //运费模版 编辑
    Route::put('shipping/template/:template_id', 'addon\fengchao\app\adminapi\controller\delivery\ShippingTemplate@edit');

    //运费模版 删除
    Route::delete('shipping/template/:template_id', 'addon\fengchao\app\adminapi\controller\delivery\ShippingTemplate@del');


    //自提门店列表（分页）
    Route::get('delivery/store', 'addon\fengchao\app\adminapi\controller\delivery\Store@lists');

    //自提门店列表（不分页）
    Route::get('delivery/store/list', 'addon\fengchao\app\adminapi\controller\delivery\Store@getList');

    //自提门店详情
    Route::get('delivery/store/:id', 'addon\fengchao\app\adminapi\controller\delivery\Store@info');

    //添加自提门店
    Route::post('delivery/store', 'addon\fengchao\app\adminapi\controller\delivery\Store@add');

    //编辑自提门店
    Route::put('delivery/store/:id', 'addon\fengchao\app\adminapi\controller\delivery\Store@edit');

    //删除自提门店
    Route::delete('delivery/store/:id', 'addon\fengchao\app\adminapi\controller\delivery\Store@del');

    //物流配置
    Route::get('delivery/deliveryList', 'addon\fengchao\app\adminapi\controller\delivery\Delivery@getDeliveryList');
    Route::put('delivery/setConfig', 'addon\fengchao\app\adminapi\controller\delivery\Delivery@setDeliveryConfig');

    //配送员列表
    Route::get('delivery/staff', 'addon\fengchao\app\adminapi\controller\delivery\Delivery@lists');

    //配送员详情
    Route::get('delivery/staff/:id', 'addon\fengchao\app\adminapi\controller\delivery\Delivery@info');

    //添加配送员
    Route::post('delivery/staff', 'addon\fengchao\app\adminapi\controller\delivery\Delivery@add');

    //编辑配送员
    Route::put('delivery/staff/:id', 'addon\fengchao\app\adminapi\controller\delivery\Delivery@edit');

    //删除配送员
    Route::delete('delivery/staff/:id', 'addon\fengchao\app\adminapi\controller\delivery\Delivery@del');

    // 获取同城配送设置
    Route::get('local', 'addon\fengchao\app\adminapi\controller\delivery\Local@getLocal');

    // 设置同城配送
    Route::put('local', 'addon\fengchao\app\adminapi\controller\delivery\Local@setLocal');

    /************************************************** 接口管理 *******************************************************/

    // 电子面单 分页列表
    Route::get('electronic_sheet', 'addon\fengchao\app\adminapi\controller\delivery\ElectronicSheet@pages');

    // 电子面单 列表
    Route::get('electronic_sheet/list', 'addon\fengchao\app\adminapi\controller\delivery\ElectronicSheet@lists');

    // 电子面单 详情
    Route::get('electronic_sheet/:id', 'addon\fengchao\app\adminapi\controller\delivery\ElectronicSheet@info');

    // 电子面单 添加
    Route::post('electronic_sheet', 'addon\fengchao\app\adminapi\controller\delivery\ElectronicSheet@add');

    // 电子面单 编辑
    Route::put('electronic_sheet/:id', 'addon\fengchao\app\adminapi\controller\delivery\ElectronicSheet@edit');

    // 电子面单 删除
    Route::delete('electronic_sheet/:id', 'addon\fengchao\app\adminapi\controller\delivery\ElectronicSheet@del');

    // 电子面单 设为默认模板
    Route::put('electronic_sheet/setDefault/:id', 'addon\fengchao\app\adminapi\controller\delivery\ElectronicSheet@setDefault');

    // 电子面单 获取设置
    Route::get('electronic_sheet/config', 'addon\fengchao\app\adminapi\controller\delivery\ElectronicSheet@getConfig');

    // 电子面单 设置
    Route::post('electronic_sheet/config', 'addon\fengchao\app\adminapi\controller\delivery\ElectronicSheet@setConfig');

    // 电子面单 获取邮费支付方式类型
    Route::get('electronic_sheet/paytype', 'addon\fengchao\app\adminapi\controller\delivery\ElectronicSheet@getPayType');

    // 电子面单 打印
    Route::post('electronic_sheet/print', 'addon\fengchao\app\adminapi\controller\delivery\ElectronicSheet@printElectronicSheet');

    //商品分页列表
    Route::get('goods', 'addon\fengchao\app\adminapi\controller\goods\Goods@pages');

    //商品详情
    Route::get('goods/:id', 'addon\fengchao\app\adminapi\controller\goods\Goods@info');

    //添加实物商品
    Route::post('goods', 'addon\fengchao\app\adminapi\controller\goods\Goods@add');

    //编辑实物商品
    Route::put('goods/:id', 'addon\fengchao\app\adminapi\controller\goods\Goods@edit');

    // 商品添加/编辑数据
    Route::get('goods/init', 'addon\fengchao\app\adminapi\controller\goods\Goods@init');

    //添加虚拟商品
    Route::post('goods/virtual', 'addon\fengchao\app\adminapi\controller\goods\VirtualGoods@add');

    //编辑虚拟商品
    Route::put('goods/virtual/:id', 'addon\fengchao\app\adminapi\controller\goods\VirtualGoods@edit');

    // 商品添加/编辑数据
    Route::get('goods/virtual/init', 'addon\fengchao\app\adminapi\controller\goods\VirtualGoods@init');

    //删除商品
    Route::put('goods/delete', 'addon\fengchao\app\adminapi\controller\goods\Goods@del');

    // 回收站商品分页列表
    Route::get('goods/recycle', 'addon\fengchao\app\adminapi\controller\goods\Goods@recyclePages');

    //商品恢复
    Route::put('goods/recycle', 'addon\fengchao\app\adminapi\controller\goods\Goods@recycle');

    // 修改商品排序号
    Route::put('goods/sort', 'addon\fengchao\app\adminapi\controller\goods\Goods@editSort');

    // 修改商品上下架状态
    Route::put('goods/status', 'addon\fengchao\app\adminapi\controller\goods\Goods@editStatus');

    // 复制商品
    Route::put('goods/copy/:goods_id', 'addon\fengchao\app\adminapi\controller\goods\Goods@copy');

    // 获取商品选择分页列表
    Route::get('goods/select', 'addon\fengchao\app\adminapi\controller\goods\Goods@select');

    // 获取商品选择分页列表带sku
    Route::get('goods/selectgoodssku', 'addon\fengchao\app\adminapi\controller\goods\Goods@selectGoodsSku');

    // 获取商品SKU规格列表
    Route::get('goods/sku', 'addon\fengchao\app\adminapi\controller\goods\Goods@sku');

    // 编辑商品规格列表库存
    Route::put('goods/sku/stock', 'addon\fengchao\app\adminapi\controller\goods\Goods@editGoodsListStock');

    // 编辑商品规格列表价格
    Route::put('goods/sku/price', 'addon\fengchao\app\adminapi\controller\goods\Goods@editGoodsListPrice');

    // 编辑商品规格列表会员价格
    Route::put('goods/sku/member_price', 'addon\fengchao\app\adminapi\controller\goods\Goods@editGoodsListMemberPrice');

    // 获取商品SKU规格列表
    Route::get('goods/active/count', 'addon\fengchao\app\adminapi\controller\goods\Goods@getActiveGoodsCount');

    // 获取商品类型
    Route::get('goods/type', 'addon\fengchao\app\adminapi\controller\goods\Goods@type');

    //商品标签分页列表
    Route::get('goods/label', 'addon\fengchao\app\adminapi\controller\goods\Label@pages');

    //商品标签列表
    Route::get('goods/label/list', 'addon\fengchao\app\adminapi\controller\goods\Label@lists');

    //商品标签详情
    Route::get('goods/label/:id', 'addon\fengchao\app\adminapi\controller\goods\Label@info');

    //添加商品标签
    Route::post('goods/label', 'addon\fengchao\app\adminapi\controller\goods\Label@add');

    //编辑商品标签
    Route::put('goods/label/:id', 'addon\fengchao\app\adminapi\controller\goods\Label@edit');

    //删除商品标签
    Route::delete('goods/label/:id', 'addon\fengchao\app\adminapi\controller\goods\Label@del');

    // 修改商品标签排序号
    Route::put('goods/label/sort', 'addon\fengchao\app\adminapi\controller\goods\Label@modifySort');

    // 修改商品标签排序号
    Route::put('goods/label/status', 'addon\fengchao\app\adminapi\controller\goods\Label@modifyStatus');

    //商品标签分组分页列表
    Route::get('goods/label/group', 'addon\fengchao\app\adminapi\controller\goods\LabelGroup@pages');

    //商品标签分组列表
    Route::get('goods/label/group/list', 'addon\fengchao\app\adminapi\controller\goods\LabelGroup@lists');

    //商品标签分组详情
    Route::get('goods/label/group/:id', 'addon\fengchao\app\adminapi\controller\goods\LabelGroup@info');

    //添加商品标签分组
    Route::post('goods/label/group', 'addon\fengchao\app\adminapi\controller\goods\LabelGroup@add');

    //编辑商品标签分组
    Route::put('goods/label/group/:id', 'addon\fengchao\app\adminapi\controller\goods\LabelGroup@edit');

    //删除商品标签分组
    Route::delete('goods/label/group/:id', 'addon\fengchao\app\adminapi\controller\goods\LabelGroup@del');

    // 修改商品标签分组排序号
    Route::put('goods/label/group/sort', 'addon\fengchao\app\adminapi\controller\goods\LabelGroup@modifySort');

    //商品品牌分页列表
    Route::get('goods/brand', 'addon\fengchao\app\adminapi\controller\goods\Brand@pages');

    //商品品牌列表
    Route::get('goods/brand/list', 'addon\fengchao\app\adminapi\controller\goods\Brand@lists');

    //商品品牌详情
    Route::get('goods/brand/:id', 'addon\fengchao\app\adminapi\controller\goods\Brand@info');

    //添加商品品牌
    Route::post('goods/brand', 'addon\fengchao\app\adminapi\controller\goods\Brand@add');

    //编辑商品品牌
    Route::put('goods/brand/:id', 'addon\fengchao\app\adminapi\controller\goods\Brand@edit');

    //删除商品品牌
    Route::delete('goods/brand/:id', 'addon\fengchao\app\adminapi\controller\goods\Brand@del');

    // 修改商品品牌排序号
    Route::put('goods/brand/sort', 'addon\fengchao\app\adminapi\controller\goods\Brand@modifySort');

    //商品服务分页列表
    Route::get('goods/service', 'addon\fengchao\app\adminapi\controller\goods\Service@pages');

    //商品服务列表
    Route::get('goods/service/list', 'addon\fengchao\app\adminapi\controller\goods\Service@lists');

    //商品服务详情
    Route::get('goods/service/:id', 'addon\fengchao\app\adminapi\controller\goods\Service@info');

    //添加商品服务
    Route::post('goods/service', 'addon\fengchao\app\adminapi\controller\goods\Service@add');

    //编辑商品服务
    Route::put('goods/service/:id', 'addon\fengchao\app\adminapi\controller\goods\Service@edit');

    //删除商品服务
    Route::delete('goods/service/:id', 'addon\fengchao\app\adminapi\controller\goods\Service@del');

    //商品分类列表树结构
    Route::get('goods/tree', 'addon\fengchao\app\adminapi\controller\goods\Category@tree');

    Route::get('goods/category', 'addon\fengchao\app\adminapi\controller\goods\Category@lists');

    //商品分类详情
    Route::get('goods/category/:id', 'addon\fengchao\app\adminapi\controller\goods\Category@info');

    //添加商品分类
    Route::post('goods/category', 'addon\fengchao\app\adminapi\controller\goods\Category@add');

    //编辑商品分类
    Route::put('goods/category/:id', 'addon\fengchao\app\adminapi\controller\goods\Category@edit');

    //删除商品分类
    Route::delete('goods/category/:id', 'addon\fengchao\app\adminapi\controller\goods\Category@del');

    //编辑商品分类
    Route::post('goods/category/update', 'addon\fengchao\app\adminapi\controller\goods\Category@editCategory');

    // 获取商品分类配置
    Route::post('goods/category/config', 'addon\fengchao\app\adminapi\controller\goods\Category@setGoodsCategoryConfig');

    // 获取商品分类配置
    Route::get('goods/category/config', 'addon\fengchao\app\adminapi\controller\goods\Category@getGoodsCategoryConfig');

    // 获取商品分类树结构供弹框调用
    Route::get('goods/category/components', 'addon\fengchao\app\adminapi\controller\goods\Category@components');

    // 商品参数分页列表
    Route::get('goods/attr', 'addon\fengchao\app\adminapi\controller\goods\Attr@pages');

    // 商品参数列表
    Route::get('goods/attr/list', 'addon\fengchao\app\adminapi\controller\goods\Attr@lists');

    // 商品参数详情
    Route::get('goods/attr/:id', 'addon\fengchao\app\adminapi\controller\goods\Attr@info');

    // 添加商品参数
    Route::post('goods/attr', 'addon\fengchao\app\adminapi\controller\goods\Attr@add');

    // 编辑商品参数
    Route::put('goods/attr/:id', 'addon\fengchao\app\adminapi\controller\goods\Attr@edit');

    // 删除商品参数
    Route::delete('goods/attr/:id', 'addon\fengchao\app\adminapi\controller\goods\Attr@del');

    // 修改商品参数排序号
    Route::put('goods/attr/sort', 'addon\fengchao\app\adminapi\controller\goods\Attr@modifySort');

    // 修改商品参数名称
    Route::put('goods/attr/attr_name', 'addon\fengchao\app\adminapi\controller\goods\Attr@modifyAttrName');

    // 修改商品参数值
    Route::put('goods/attr/attr_value', 'addon\fengchao\app\adminapi\controller\goods\Attr@modifyAttrValueFormat');

    /************************************************** 订单相关接口 *****************************************************/
    //交易配置
    Route::post('order/config', 'addon\fengchao\app\adminapi\controller\order\Config@setConfig');
    Route::get('order/config', 'addon\fengchao\app\adminapi\controller\order\Config@getConfig');


    //获取 订单类型
    Route::get('order/type', 'addon\fengchao\app\adminapi\controller\order\Order@getOrderType');

    //获取 订单状态
    Route::get('order/status', 'addon\fengchao\app\adminapi\controller\order\Order@getOrderStatus');

    //订单关闭
    Route::put('order/close/:id', 'addon\fengchao\app\adminapi\controller\order\Order@orderClose');

    //订单改价
    Route::put('order/edit_price', 'addon\fengchao\app\adminapi\controller\order\Order@editPrice');

    //订单配送修改
    Route::put('order/edit_delivery', 'addon\fengchao\app\adminapi\controller\order\Order@editDelivery');

    //订单配送修改信息
    Route::get('order/edit_delivery', 'addon\fengchao\app\adminapi\controller\order\Order@editDeliveryData');

    //订单发货
    Route::put('order/delivery', 'addon\fengchao\app\adminapi\controller\order\Order@orderDelivery');

    //订单项发货
    Route::put('order/goods/delivery/:id', 'addon\fengchao\app\adminapi\controller\order\Order@orderDelivery');

    //获取订单配送方式
    Route::get('order/delivery_type', 'addon\fengchao\app\adminapi\controller\order\Order@getDeliveryType');

    //商家留言
    Route::put('order/fengchao_remark', 'addon\fengchao\app\adminapi\controller\order\Order@setfengchaoRemark');

    //订单完成
    Route::put('order/finish/:id', 'addon\fengchao\app\adminapi\controller\order\Order@orderFinish');

    //获取 物流包裹信息（跟踪信息）
    Route::get('order/delivery/package', 'addon\fengchao\app\adminapi\controller\order\Order@getOrderPackage');

    //获取 物流包裹列表
    Route::get('order/delivery/package/list', 'addon\fengchao\app\adminapi\controller\order\Order@getDeliveryPackageList');

    //获取 支付类型
    Route::get('order/pay/type', 'addon\fengchao\app\adminapi\controller\order\Order@getPayType');

    //获取 订单来源
    Route::get('order/from', 'addon\fengchao\app\adminapi\controller\order\Order@getOrderFrom');

    //订单维权 列表
    Route::get('order/refund', 'addon\fengchao\app\adminapi\controller\refund\Refund@lists');

    //订单维权 详情
    Route::get('order/refund/:id', 'addon\fengchao\app\adminapi\controller\refund\Refund@detail');

    //订单维权审核
    Route::put('order/refund/audit/:order_refund_no', 'addon\fengchao\app\adminapi\controller\refund\Refund@auditApply');

    //订单维权审核
    Route::put('order/refund/delivery/:order_refund_no', 'addon\fengchao\app\adminapi\controller\refund\Refund@auditRefundGoods');

    /************************************************** 订单发货批量操作相关接口 *****************************************************/

    //订单批量操作 列表
    Route::get('order_batch_delivery', 'addon\fengchao\app\adminapi\controller\order\Order@getOrderBatchDeliveryPage');

    //订单批量操作 详情
    Route::get('order_batch_delivery/:id', 'addon\fengchao\app\adminapi\controller\order\Order@getOrderBatchDeliveryInfo');

    //批量发货
    Route::put('order_batch_delivery/add_batch_order_delivery', 'addon\fengchao\app\adminapi\controller\order\Order@addBatchOrderDelivery');

    //订单批量操作类型
    Route::get('order_batch_delivery/get_type', 'addon\fengchao\app\adminapi\controller\order\Order@getBatchType');

    //订单批量操作状态
    Route::get('order_batch_delivery/get_status', 'addon\fengchao\app\adminapi\controller\order\Order@getBatchStatus');

    //营销中心
    Route::get('marketing', 'addon\fengchao\app\adminapi\controller\marketing\Index@index');

    /************************************************** 优惠券相关接口 *****************************************************/
    //优惠券列表
    Route::get('goods/coupon', 'addon\fengchao\app\adminapi\controller\marketing\Coupon@lists');

    //优惠券初始化信息
    Route::get('goods/coupon/init', 'addon\fengchao\app\adminapi\controller\marketing\Coupon@init');

    //添加优惠券
    Route::post('goods/coupon', 'addon\fengchao\app\adminapi\controller\marketing\Coupon@add');

    //优惠券领取记录
    Route::get('goods/coupon/records', 'addon\fengchao\app\adminapi\controller\marketing\Coupon@getMemberCoupon');

    //优惠券详情
    Route::get('goods/coupon/detail/:id', 'addon\fengchao\app\adminapi\controller\marketing\Coupon@info');

    //编辑优惠券
    Route::put('goods/coupon/edit/:id', 'addon\fengchao\app\adminapi\controller\marketing\Coupon@edit');

    //优惠券设置状态
    Route::put('goods/coupon/setstatus/:status', 'addon\fengchao\app\adminapi\controller\marketing\Coupon@setCouponStatus');

    //优惠券失效
    Route::put('goods/coupon/invalid/:id', 'addon\fengchao\app\adminapi\controller\marketing\Coupon@couponInvalid');

    //删除优惠券
    Route::delete('goods/coupon/:id', 'addon\fengchao\app\adminapi\controller\marketing\Coupon@del');

    //查询选中的优惠券
    Route::get('goods/coupon/selected', 'addon\fengchao\app\adminapi\controller\marketing\Coupon@getSelectedLists');

    //优惠券状态列表
    Route::get('goods/coupon/status', 'addon\fengchao\app\adminapi\controller\marketing\Coupon@getCouponStatus');

    //商家地址库列表
    Route::get('fengchao_address', 'addon\fengchao\app\adminapi\controller\fengchao_address\fengchaoAddress@lists');

    //商家地址库详情
    Route::get('fengchao_address/:id', 'addon\fengchao\app\adminapi\controller\fengchao_address\fengchaoAddress@info');

    //添加商家地址库
    Route::post('fengchao_address', 'addon\fengchao\app\adminapi\controller\fengchao_address\fengchaoAddress@add');

    //编辑商家地址库
    Route::put('fengchao_address/:id', 'addon\fengchao\app\adminapi\controller\fengchao_address\fengchaoAddress@edit');

    //删除商家地址库
    Route::delete('fengchao_address/:id', 'addon\fengchao\app\adminapi\controller\fengchao_address\fengchaoAddress@del');

    // 默认发货地址
    Route::get('fengchao_address/default/delivery', 'addon\fengchao\app\adminapi\controller\fengchao_address\fengchaoAddress@defaultDelivery');

    //获取商家收货地址库
    Route::get('order/refund/address', 'addon\fengchao\app\adminapi\controller\fengchao_address\fengchaoAddress@getList');

    //商品评价 列表
    Route::get('goods/evaluate', 'addon\fengchao\app\adminapi\controller\goods\Evaluate@lists');

    //商品评价 添加
    Route::post('goods/evaluate', 'addon\fengchao\app\adminapi\controller\goods\Evaluate@add');

    //商品评价 删除
    Route::delete('goods/evaluate/:id', 'addon\fengchao\app\adminapi\controller\goods\Evaluate@del');

    //商品评价 回复
    Route::put('goods/evaluate/reply/:id', 'addon\fengchao\app\adminapi\controller\goods\Evaluate@evaluateReply');

    //商品评价 通过
    Route::put('goods/evaluate/adopt/:id', 'addon\fengchao\app\adminapi\controller\goods\Evaluate@adopt');

    //商品评价 拒绝
    Route::put('goods/evaluate/refuse/:id', 'addon\fengchao\app\adminapi\controller\goods\Evaluate@refuse');

    //商品评价 置顶
    Route::put('goods/evaluate/topping/:id', 'addon\fengchao\app\adminapi\controller\goods\Evaluate@topping');

    //商品评价 取消置顶
    Route::put('goods/evaluate/cancel_topping/:id', 'addon\fengchao\app\adminapi\controller\goods\Evaluate@cancelTopping');

    Route::get('stat/total', 'addon\fengchao\app\adminapi\controller\Stat@total');
    Route::get('stat/today', 'addon\fengchao\app\adminapi\controller\Stat@today');
    Route::get('stat/yesterday', 'addon\fengchao\app\adminapi\controller\Stat@yesterday');
    Route::get('stat', 'addon\fengchao\app\adminapi\controller\Stat@stat');
    Route::get('stat/order', 'addon\fengchao\app\adminapi\controller\Stat@order');
    Route::get('stat/goods', 'addon\fengchao\app\adminapi\controller\Stat@goods');

    // 发票列表
    Route::get('invoice', 'addon\fengchao\app\adminapi\controller\order\Invoice@lists');

    // 发票信息
    Route::get('invoice/:id', 'addon\fengchao\app\adminapi\controller\order\Invoice@info');

    // 开票
    Route::put('invoice/:id', 'addon\fengchao\app\adminapi\controller\order\Invoice@invoicing');

    /************************************************** 限时折扣 *****************************************************/
    //限时折扣列表
    Route::get('active/discount', 'addon\fengchao\app\adminapi\controller\marketing\Discount@lists');

    //添加
    Route::post('active/discount', 'addon\fengchao\app\adminapi\controller\marketing\Discount@add');

    //编辑
    Route::put('active/discount/:active_id', 'addon\fengchao\app\adminapi\controller\marketing\Discount@edit');

    //删除
    Route::delete('active/discount/:active_id', 'addon\fengchao\app\adminapi\controller\marketing\Discount@del');

    //关闭
    Route::put('active/discount/close/:active_id', 'addon\fengchao\app\adminapi\controller\marketing\Discount@close');

    //详情
    Route::get('active/discount/:active_id', 'addon\fengchao\app\adminapi\controller\marketing\Discount@detail');

    //状态
    Route::get('active/status', 'addon\fengchao\app\adminapi\controller\marketing\Discount@status');

    //参与订单
    Route::get('active/discount/order/:active_id', 'addon\fengchao\app\adminapi\controller\marketing\Discount@order');

    //参与会员
    Route::get('active/discount/member/:active_id', 'addon\fengchao\app\adminapi\controller\marketing\Discount@member');

    //参与商品
    Route::get('active/discount/goods/:active_id', 'addon\fengchao\app\adminapi\controller\marketing\Discount@goods');

    //获取配置
    Route::get('active/discount/config', 'addon\fengchao\app\adminapi\controller\marketing\Discount@banner');

    //设置配置
    Route::put('active/discount/config', 'addon\fengchao\app\adminapi\controller\marketing\Discount@setBanner');


    /************************************************** 积分商城 *****************************************************/
    //积分商城列表
    Route::get('active/exchange', 'addon\fengchao\app\adminapi\controller\marketing\Exchange@lists');

    //商品类型
    Route::get('active/exchange/type', 'addon\fengchao\app\adminapi\controller\marketing\Exchange@type');

    //商品类型
    Route::get('active/exchange/status', 'addon\fengchao\app\adminapi\controller\marketing\Exchange@status');

    //添加积分商城
    Route::post('active/exchange', 'addon\fengchao\app\adminapi\controller\marketing\Exchange@add');

    //积分商城详情
    Route::get('active/exchange/:id', 'addon\fengchao\app\adminapi\controller\marketing\Exchange@detail');

    //编辑积分商城
    Route::put('active/exchange/:id', 'addon\fengchao\app\adminapi\controller\marketing\Exchange@edit');

    //修改积分商城上下架状态
    Route::put('active/exchange/status/:id', 'addon\fengchao\app\adminapi\controller\marketing\Exchange@editStatus');

    //删除
    Route::delete('active/exchange/:id', 'addon\fengchao\app\adminapi\controller\marketing\Exchange@del');

    //修改排序号
    Route::put('active/exchange/sort/:id', 'addon\fengchao\app\adminapi\controller\marketing\Exchange@modifySort');

    /************************************************** 新人专享 *****************************************************/
    //新人专享配置
    Route::get('active/newcomer/config', 'addon\fengchao\app\adminapi\controller\marketing\Newcomer@getConfig');

    //新人专享设置
    Route::put('active/newcomer/config', 'addon\fengchao\app\adminapi\controller\marketing\Newcomer@setConfig');

    //新人专享商品选择列表
    Route::get('active/newcomer/goods/select', 'addon\fengchao\app\adminapi\controller\marketing\Newcomer@select');

    //新人专享商品选择已选商品列表
    Route::get('active/newcomer/goods/selectgoodssku', 'addon\fengchao\app\adminapi\controller\marketing\Newcomer@selectGoodsSku');

})->middleware([
    AdminCheckToken::class,
    AdminCheckRole::class,
    AdminLog::class
]);
// 沙盒
//主网api
Route::group('sandbox', function() {


//   Route::get('getApi/:id', 'addon\fengchao\app\adminapi\controller\sandbox\SandBox@info');
//   Route::get('getApi/fake/list', 'addon\fengchao\app\adminapi\controller\sandbox\FakeData@list');
//   Route::get('getApi/fake/:id', 'addon\fengchao\app\adminapi\controller\sandbox\FakeData@fake');
    Route::get('fake/list', 'addon\fengchao\app\adminapi\controller\sandbox\FakeData@list');
    Route::get('fake/:site_id/:id', 'addon\fengchao\app\adminapi\controller\sandbox\FakeData@fake');

});