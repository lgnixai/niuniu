<?php
// +----------------------------------------------------------------------
// | Niucloud-admin 企业快速开发的多应用管理平台
// +----------------------------------------------------------------------
// | 官方网址：https://www.niucloud.com
// +----------------------------------------------------------------------
// | niucloud团队 版权所有 开源版本可自由商用
// +----------------------------------------------------------------------
// | Author: Niucloud Team
// +----------------------------------------------------------------------

namespace addon\fengchao\app\adminapi\controller\order;

use addon\fengchao\app\dict\order\OrderBatchDeliveryDict;
use addon\fengchao\app\dict\order\OrderDeliveryDict;
use addon\fengchao\app\dict\order\OrderDict;

use addon\fengchao\app\service\api\order\OrderService;
use app\dict\common\ChannelDict;
use app\dict\pay\PayDict;
use core\base\BaseAdminController;
use think\Response;

class Order extends BaseAdminController
{
    /**
     * 订单列表
     * @return Response
     */
    public function lists()
    {
        $data = $this->request->params([

            [ 'order_code', '' ],
            [ 'create_time', [] ],
        ]);

        return success(( new OrderService() )->getPage($data));
    }

    /**
     * 订单详情
     * @param int $order_id
     * @return Response
     */
    public function detail(int $id)
    {
        return success(( new OrderService() )->getDetail($id));
    }


}
