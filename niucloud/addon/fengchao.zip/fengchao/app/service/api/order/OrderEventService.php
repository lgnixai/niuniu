<?php

namespace addon\fengchao\app\service\api\order;
use addon\fengchao\app\job\order_event\OrderCreateAfter;
use addon\fengchao\app\model\order\Order;
use core\base\BaseApiService;

/**
 * 订单事件服务层
 */
class OrderEventService extends BaseApiService
{

    public function __construct()
    {
        parent::__construct();
        $this->model = new Order();
    }

    /**
     * 订单创建事件
     * @param $data
     * @return true
     */
    public static function orderCreate($data){
        event('orderCreate', $data);
        return true;
    }

    /**
     * 订单创建后事件
     * @param $data
     * @return true
     */
    public static function orderCreateAfter($data){
        OrderCreateAfter::dispatch(['data' => $data]);
        return true;
    }

    //接口请求日志
    public static function createOrderLog($data){
        event('CreateOrderLog', $data);
        return true;
    }



}
