<?php
// +----------------------------------------------------------------------
// | Niucloud-admin 企业快速开发的多应用管理平台
// +----------------------------------------------------------------------
// | 官方网址：https://www.niucloud.com
// +----------------------------------------------------------------------
// | niucloud团队 版权所有 开源版本可自由商用
// +----------------------------------------------------------------------
// | Author: Niucloud Team
// +----------------------------------------------------------------------

namespace addon\fengchao\app\service\api\express;

use addon\fengchao\app\service\core\order\CoreOrderConfigService;
use core\base\BaseAdminService;
use core\base\BaseApiService;
use function Symfony\Component\Translation\t;


/**
 * 订单设置服务层
 * Class ConfigService
 * @package adaddon\fengchao\app\service\admin\order
 */
class ExpressService extends BaseApiService
{


    public function __construct()
    {

    }

    public function Kdniao($data)
    {
        $EBusinessID = 350238;
        $AppKey = "082bff05-66ba-46b3-ae64-804c7cff990c";
        $ReqURL = "http://183.62.170.46:8081/api/dist";

// 组装系统级参数
        $datas = array(
            'EBusinessID' => $EBusinessID,
            'RequestType' => $data['RequestType'],
            'RequestData' => urlencode($data["RequestData"]),
            'DataType' => '2',
        );
        $datas['DataSign'] = $this->encrypt($data["RequestData"], $AppKey);
        //以form表单形式提交post请求，post请求体中包含了应用级参数和系统级参数
        $result = $this->sendPost($ReqURL, $datas);
        return  json_decode($result,true);
    }

    /**
     * 获取交易设置
     * @return array
     */
    public function KdniaoDev($data)
    {
        $EBusinessID = 350238;
        $AppKey = "082bff05-66ba-46b3-ae64-804c7cff990c";
        $ReqURL = "http://183.62.170.46:8081/api/dist";

// 组装系统级参数
        $datas = array(
            'EBusinessID' => $EBusinessID,
            'RequestType' => $data['RequestType'],
            'RequestData' => urlencode($data["RequestData"]),
            'DataType' => '2',
        );
        $datas['DataSign'] = $this->encrypt($data["RequestData"], $AppKey);
        //以form表单形式提交post请求，post请求体中包含了应用级参数和系统级参数
        $result = $this->sendPost($ReqURL, $datas);
        return  json_decode($result);
    }

    /**
     *  post提交数据
     * @param string $url 请求Url
     * @param array $datas 提交的数据
     * @return url响应返回的html
     */
    public function sendPost($url, $datas)
    {
        $postdata = http_build_query($datas);
        $options = array(
            'http' => array(
                'method' => 'POST',
                'header' => 'Content-type:application/x-www-form-urlencoded',
                'content' => $postdata,
                'timeout' => 15 * 60 // 超时时间（单位:s）
            )
        );
        $context = stream_context_create($options);
        $result = file_get_contents($url, false, $context);
        return $result;
    }

    /**
     * 电商Sign签名生成
     * @param data 内容
     * @param api_secret api_secret
     * @return DataSign签名
     */
    public function encrypt($data, $api_secret)
    {
        return urlencode(base64_encode(md5($data . $api_secret)));
    }

}
