<?php
// +----------------------------------------------------------------------
// | Niucloud-admin 企业快速开发的saas管理平台
// +----------------------------------------------------------------------
// | 官方网址：https://www.niucloud.com
// +----------------------------------------------------------------------
// | niucloud团队 版权所有 开源版本可自由商用
// +----------------------------------------------------------------------
// | Author: Niucloud Team
// +----------------------------------------------------------------------

namespace addon\fengchao\app\model\site;
use app\model\site\Site;
use app\dict\member\MemberAccountChangeTypeDict;
use app\dict\member\MemberAccountTypeDict;
use app\model\member\Member;
use core\base\BaseModel;
use think\db\Query;
use think\model\relation\HasOne;

/**
 * 会员账户流水（账单）模型
 * Class MemberAccount
 * @package app\model\member
 */
class SiteBalanceLog extends BaseModel
{

    /**
     * 数据表主键
     * @var string
     */
    protected $pk = 'id';

    /**
     * 模型名称
     * @var string
     */
    protected $name = 'fengchao_site_balance_log';


    /**
     * 账户类型
     * @param $value
     * @param $data
     * @return string
     */
    public function getAccountTypeNameAttr($value, $data)
    {
        if (empty($data['account_type']))
            return '';
        return MemberAccountTypeDict::getType()[$data['account_type']] ?? '';
    }

    /**
     * 会员信息
     * @return HasOne
     */
    public function memberInfo()
    {
        return $this->hasOne(Member::class, 'member_id', 'member_id')->joinType('left')
            ->withField('member_id,member_no, username, mobile, nickname, headimg')
            ->bind(['username', 'mobile', 'nickname', 'headimg']);
    }

    /**
     * 会员关联
     * @return HasOne
     */
    public function site()
    {
        return $this->hasOne(Site::class, 'site_id', 'site_id')->withField('site_id, site_name')->joinType('inner');
    }

    /**
     * 获取account_data
     * @param $value
     * @param $data
     * @return int
     */
    public function getAccountDataAttr($value, $data)
    {
        if ($data['account_type'] == 'point' || $data['account_type'] == 'growth')
            return (int)$data['account_data'];
        else
            return $data['account_data'];
    }

    /**
     * 获取account_sum
     * @param $value
     * @param $data
     * @return int
     */
    public function getAccountSumAttr($value, $data)
    {
        if ($data['account_type'] == 'point' || $data['account_type'] == 'growth')
            return (int)$data['account_sum'];
        else
            return $data['account_sum'];
    }

    /**
     * 获取账户变动类型名称
     * @param $value
     * @param $data
     * @return array|mixed|string
     */
    public function getFromTypeNameAttr($value, $data)
    {
        if (isset($data['from_type'], $data['account_type']))
            return MemberAccountChangeTypeDict::getType($data['account_type'])[$data['from_type']]['name'] ?? '';
        else
            return '';
    }

    /**
     * 会员搜索
     * @param $query
     * @param $value
     * @param $data
     */
    public function searchMemberIdAttr($query, $value, $data)
    {
        if ($value) {
            $query->where('member_id', $value);
        }
    }

    /**
     * 关键词搜索
     * @param $query
     * @param $value
     * @param $data
     */
    public function searchKeywordAttr(Query $query, $value, $data)
    {
        if ($value != '') {
            $query->whereLike('memo', '%'.$value.'%');
        }
    }

    /**
     * 金额大于
     * @param $query
     * @param $value
     * @param $data
     */
    public function searchAccountDataGtAttr($query, $value, $data)
    {
        if ($value !== '' && $value !== null) {
            $query->where('account_data', '>',$value);
        }
    }

    /**
     * 金额小于
     * @param $query
     * @param $value
     * @param $data
     */
    public function searchAccountDataLtAttr($query, $value, $data)
    {
        if ($value !== '' && $value !== null) {
            $query->where('account_data', '<',$value);
        }
    }

    /**
     * 会员搜索(用于关联表查询)
     * @param $query
     * @param $value
     * @param $data
     */
    public function searchJoinMemberIdAttr($query, $value, $data)
    {
        if ($value) {
            $query->where('member_account_log.member_id', $value);
        }
    }

    /**
     * 类型搜索
     * @param $query
     * @param $value
     * @param $data
     */
    public function searchFromTypeAttr($query, $value, $data)
    {
        if ($value) {
            $query->where('from_type', $value);
        }
    }

    /**
     * 账户类型搜索
     * @param $query
     * @param $value
     * @param $data
     */
    public function searchAccountTypeAttr($query, $value, $data)
    {
        if ($value) {
            $query->where('account_type', $value);
        }
    }

    /**
     * 创建时间搜索器
     * @param $query
     * @param $value
     * @param $data
     */
    public function searchCreateTimeAttr($query, $value, $data)
    {
        $start_time = empty($value[0]) ? 0 : strtotime($value[0]);
        $end_time = empty($value[1]) ? 0 : strtotime($value[1]);
        if ($start_time > 0 && $end_time > 0) {
            $query->whereBetweenTime('create_time', $start_time, $end_time);
        } else if ($start_time > 0 && $end_time == 0) {
            $query->where([['create_time', '>=', $start_time]]);
        } else if ($start_time == 0 && $end_time > 0) {
            $query->where([['create_time', '<=', $end_time]]);
        }
    }

    /**
     * 创建关联表时间搜索器
     * @param $query
     * @param $value
     * @param $data
     */
    public function searchJoinCreateTimeAttr($query, $value, $data)
    {
        $start_time = empty($value[0]) ? 0 : strtotime($value[0]);
        $end_time = empty($value[1]) ? 0 : strtotime($value[1]);
        if ($start_time > 0 && $end_time > 0) {
            $query->whereBetweenTime('site_balance_log.create_time', $start_time, $end_time);
        } else if ($start_time > 0 && $end_time == 0) {
            $query->where([['site_balance_log.create_time', '>=', $start_time]]);
        } else if ($start_time == 0 && $end_time > 0) {
            $query->where([['site_balance_log.create_time', '<=', $end_time]]);
        }
    }


}
