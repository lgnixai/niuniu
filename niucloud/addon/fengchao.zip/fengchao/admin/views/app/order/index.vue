<template>
  <div class="main-container">
    <el-card class="box-card !border-none" shadow="never">

      <div class="flex justify-between items-center">
        <div class="detail-head !m-0">
          <span class="right">{{ pageName }}</span>
        </div>

      </div>

      <el-card class="box-card !border-none my-[10px] table-search-wrap" shadow="never">
        <el-form :inline="true" :model="orderTable.searchParam" ref="searchFormRef">
          <el-form-item :label="t('orderCode')" prop="order_code">
            <el-input v-model.trim="orderTable.searchParam.company_name" :placeholder="t('orderCodePlaceholder')"/>
          </el-form-item>
          <el-form-item :label="t('createTime')" prop="create_time">
            <el-date-picker v-model="orderTable.searchParam.create_time" type="datetimerange"
                            value-format="YYYY-MM-DD HH:mm:ss" :start-placeholder="t('startDate')"
                            :end-placeholder="t('endDate')" />
          </el-form-item>

          <el-form-item>
            <el-button type="primary" @click="loadOrderList()">{{ t('search') }}</el-button>
            <el-button @click="resetForm(searchFormRef)">{{ t('reset') }}</el-button>
          </el-form-item>
        </el-form>
      </el-card>

      <div class="mt-[10px]">
        <el-table :data="orderTable.data" size="large" v-loading="orderTable.loading">
          <template #empty>
            <span>{{ !orderTable.loading ? t('emptyData') : '' }}</span>
          </template>
          <el-table-column prop="order_code" :label="t('orderCode')" min-width="120"/>

          <el-table-column prop="kdn_code" :label="t('kdnCode')" min-width="120"/>
          <el-table-column prop="price_data.weight" :label="t('weight')" min-width="120"/>
          <el-table-column prop="price_data.totalFee" :label="t('totalFee')" min-width="120"/>

<!--          <el-table-column :label="t('operation')" fixed="right" align="right" min-width="120">-->
<!--            <template #default="{ row }">-->
<!--              <el-button type="primary" link @click="editEvent(row)">{{ t('edit') }}</el-button>-->
<!--              <el-button type="primary" link @click="deleteEvent(row.company_id)">{{ t('delete') }}-->
<!--              </el-button>-->
<!--            </template>-->
<!--          </el-table-column>-->

        </el-table>
        <div class="mt-[16px] flex justify-end">
          <el-pagination v-model:current-page="orderTable.page" v-model:page-size="orderTable.limit"
                         layout="total, sizes, prev, pager, next, jumper" :total="orderTable.total"
                         @size-change="loadOrderList()" @current-change="loadOrderList"/>
        </div>
      </div>
    </el-card>
  </div>
</template>

<script lang="ts" setup>
import {reactive, ref} from 'vue'
import {t} from '@/lang'
import {getOrderList, } from '@/addon/fengchao/api/order'
import {img} from '@/utils/common'
import {ElMessageBox, FormInstance} from 'element-plus'
import {useRoute, useRouter} from 'vue-router'

const route = useRoute()
const router = useRouter()
const pageName = route.meta.title

const orderTable = reactive({
  page: 1,
  limit: 10,
  total: 0,
  loading: true,
  data: [],
  searchParam: {
    order_code: '',
    create_time: '',
  }
})

const searchFormRef = ref<FormInstance>()

/**
 * 获取物流公司列表
 */
const loadOrderList = (page: number = 1) => {
  orderTable.loading = true
  orderTable.page = page

  getOrderList({
    page: orderTable.page,
    limit: orderTable.limit,
    ...orderTable.searchParam
  }).then(res => {
    orderTable.loading = false
    orderTable.data = res.data.data
    orderTable.total = res.data.total
  }).catch(() => {
    orderTable.loading = false
  })
}
loadOrderList()

const resetForm = (formEl: FormInstance | undefined) => {
  if (!formEl) return
  formEl.resetFields()
  loadOrderList()
}
</script>

<style lang="scss" scoped>
</style>
